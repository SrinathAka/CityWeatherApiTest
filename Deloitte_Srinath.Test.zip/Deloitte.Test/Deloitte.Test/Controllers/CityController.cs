﻿using System.Threading.Tasks;
using Deloitte.Test.Core.Interfaces;
using Deloitte.Test.Core.Models;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.Test.Controllers
{
    //[Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CityController : ControllerBase
    {
        private ICityService _cityService;
        public CityController(ICityService cityService)
        {
            _cityService = cityService;
        }

        // GET api/city/{name}
        [HttpGet("{name}")]
        public async Task<IActionResult> Get(string name)
        {
           var cityResponse= await _cityService.GetCityByName(name);
            return Ok(cityResponse);
        }

        // POST api/city
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] City city)
        {
           await _cityService.AddCity(city);
            return Ok();
        }

        // PUT api/city/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] City city)
        {
            await _cityService.UpdateCity(id, city);
            return Ok();
        }

        // DELETE api/city/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _cityService.DeleteCity(id);
            return Ok();
        }
    }
}
