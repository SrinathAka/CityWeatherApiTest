﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Deloitte.Test.Api.Filters
{
    public class ErrorHandlingMiddleware
    {
        private readonly RequestDelegate next;
        private static ILogger _logger;

        public ErrorHandlingMiddleware(RequestDelegate next, ILogger<ErrorHandlingMiddleware> logger)
        {
            this.next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await next(context);
                //if (context.Response.StatusCode == 404)
                //{
                //    throw new NotSupportedException("No such resources found");
                //}
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private static Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            _logger.LogError(exception.Message + exception.InnerException + exception.StackTrace);
            var code = HttpStatusCode.InternalServerError; // 500 if unexpected
            var exceptionType = exception.GetType();
            if (exceptionType == typeof(NotImplementedException)) code = HttpStatusCode.NotImplemented;
            else if (exceptionType == typeof(UnauthorizedAccessException)) code = HttpStatusCode.Unauthorized;
            else if (exceptionType == typeof(NotSupportedException)) code = HttpStatusCode.NotFound;

            var result = JsonConvert.SerializeObject(new { error = exception.Message });
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)code;
            return context.Response.WriteAsync(result);
        }
    }
}
