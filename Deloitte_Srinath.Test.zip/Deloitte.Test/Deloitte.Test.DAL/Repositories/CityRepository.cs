﻿using Deloitte.Test.Core.Interfaces;
using Deloitte.Test.Core.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Deloitte.Test.DAL.Repositories
{
    public class CityRepository : GenericRepository<City>, ICityRepository
    {
        private IUnitOfWork _unitOfWork;

        public CityRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<List<City>> GetCityByName(string name)
        {
            var context = _unitOfWork.Get<CityContext>();
            var cities = context.Cities;

            return await cities.Where(ci => ci.Name == name).ToListAsync();
        }
    }
}
