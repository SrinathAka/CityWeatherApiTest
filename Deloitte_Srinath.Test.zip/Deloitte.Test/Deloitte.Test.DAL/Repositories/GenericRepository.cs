﻿using Deloitte.Test.Core.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Deloitte.Test.DAL.Repositories
{
    public class GenericRepository<TEntity> : IGenericRepository<TEntity> where TEntity : class
    {
        private IUnitOfWork _unitOfWork;
        private DbContext _context;
        private DbSet<TEntity> entities;
        public GenericRepository(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<TEntity> Add(TEntity entity)
        {
            CheckContext();
            await Entities.AddAsync(entity);
            return entity;
        }

        public async Task Delete(int id)
        {
            CheckContext();
            var entity = await Entities.FindAsync(id);
            if(entity!=null)
             Entities.Remove(entity);
            
        }

        public async Task<TEntity> Get(int id)
        {
            CheckContext();
            return await Entities.FindAsync(id);
        }

        public IEnumerable<TEntity> GetAll()
        {
            CheckContext();
            return Entities;
        }

        public void Update(TEntity entity)
        {
            CheckContext();
            Entities.Update(entity);
        }

        public void Save()
        {
            _unitOfWork.Commit();
        }
        private void CheckContext()
        {
            _context = _unitOfWork.Get<DbContext>();
        }

        private DbSet<TEntity> Entities
        {
            get
            {
                if (entities == null)
                {
                    entities = _context.Set<TEntity>();
                }
                return entities;
            }
        }
    }
}
