﻿using Deloitte.Test.Core.Interfaces;
using Deloitte.Test.Core.Models;
using Deloitte.Test.Core.Responses;
using Deloitte.Test.Services;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Deloitte.Test.UnitTests.ServiceTests
{
    [TestFixture]
    public class CityServiceTests
    {
        private Mock<ICityRepository> cityRepository;
        private Mock<ICountryServiceClient> countryServiceClient;
        private Mock<IWeatherServiceClient> weatherServiceClient;
        private CityService cityService;
        private City city;
        private int cityId;
        private string cityName;
        private WeatherResponse weatherResponse;
        private WeatherSystem weatherSystem;
        private List<Weather> weatherList;
        private CountryResponse countryResponse;
        [SetUp]
        public void Setup()
        {
            city = new City() {  };
            cityId = 1;
            cityName = "London";
            weatherSystem = new WeatherSystem() { Country = "GB" };
            weatherList = new List<Weather> { new Weather { Description = "Rain" } };
            weatherResponse = new WeatherResponse() { Sys= weatherSystem, Weather=weatherList };
            countryResponse = new CountryResponse() { Alpha2Code = "GB", Alpha3Code = "GBR", Currencies = new List<Currency> { new Currency { Code = "GBP" } } };
            cityRepository = new Mock<ICityRepository>();
            cityRepository.Setup(cr => cr.Add(city)).Returns(Task.FromResult(city));
            cityRepository.Setup(cr => cr.Get(cityId)).Returns(Task.FromResult(city));
            cityRepository.Setup(cr => cr.GetCityByName(cityName)).Returns(Task.FromResult(new List<City> { city}));
            cityRepository.Setup(cr => cr.Delete(cityId)).Returns(Task.CompletedTask);
            weatherServiceClient = new Mock<IWeatherServiceClient>();
            weatherServiceClient.Setup(ws => ws.GetWeatherByCityName(cityName)).Returns(Task.FromResult(weatherResponse));
            countryServiceClient = new Mock<ICountryServiceClient>();
            countryServiceClient.Setup(cs => cs.GetCountriesByCode(weatherSystem.Country)).Returns(Task.FromResult(countryResponse));
            cityService = new CityService(cityRepository.Object, countryServiceClient.Object, weatherServiceClient.Object);
        }
        [Test]
        public async Task GivenCityName_WhenSearchCityISCalled_ShouldReturnCityInfoWithCountryAndWeatherData()
        {
            var cityResponse = await cityService.GetCityByName(cityName);
            // Assert
            //Verifying Expectation that CityRepository, WeatherService and CountryService is called within CityService
            cityRepository.Verify(mock => mock.GetCityByName(cityName), Times.Once());
            weatherServiceClient.Verify(mock => mock.GetWeatherByCityName(cityName), Times.Once());
            countryServiceClient.Verify(mock => mock.GetCountriesByCode(weatherSystem.Country), Times.Once());
            //Assert 
            Assert.IsNotNull(cityResponse);
            Assert.AreEqual(cityResponse[0].Weather, weatherResponse.Weather[0].Description);
            Assert.AreEqual(cityResponse[0].CountryCode2Digit, countryResponse.Alpha2Code);
            Assert.AreEqual(cityResponse[0].CountryCode3Digit, countryResponse.Alpha3Code);
            Assert.AreEqual(cityResponse[0].CurrencyCode, countryResponse.Currencies[0].Code);
        }
        [Test]
        public async Task GivenCityObject_WhenAddCityIsCalled_ShouldSaveToLocalDataStore()
        {
            await cityService.AddCity(city);
            // Assert
            //Verifying Expectation that CityRepository is called within CityService
            cityRepository.Verify(mock => mock.Add(city), Times.Once());
            cityRepository.Verify(mock => mock.Save(), Times.Once());
        }
        [Test]
        public async Task GivenCityId_AndCityObject_WhenUpdateCityIsCalled_ShouldUpdateToLocalDataStore()
        {
            await cityService.UpdateCity(cityId,city);
            // Assert
            //Verifying Expectation that CityRepository Get,Update and Save is called within CityService
            cityRepository.Verify(mock => mock.Get(cityId), Times.Once());
            cityRepository.Verify(mock => mock.Update(city), Times.Once());
            cityRepository.Verify(mock => mock.Save(), Times.Once());
        }
        
        [Test]
        public async Task GivenCityId_WhenDeleteCityIsCalled_ShouldDeleteCityInfoFromLocalDataStore()
        {
            await cityService.DeleteCity(cityId);
            // Assert
            //Verifying Expectation that CityRepository is called within CityService
            cityRepository.Verify(mock => mock.Delete(cityId), Times.Once());
            cityRepository.Verify(mock => mock.Save(), Times.Once());
        }
    }
}
