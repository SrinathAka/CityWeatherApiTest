﻿using Deloitte.Test.Core.Interfaces;
using Deloitte.Test.Core.Models;
using Deloitte.Test.Core.Responses;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Deloitte.Test.Services
{
    public class CityService : ICityService
    {
        private ICityRepository _cityRepository;
        private ICountryServiceClient _countryServiceClient;
        private IWeatherServiceClient _weatherServiceClient;
        public CityService(ICityRepository cityRepository,
            ICountryServiceClient countryServiceClient,
            IWeatherServiceClient weatherServiceClient)
        {
            _cityRepository = cityRepository;
            _countryServiceClient = countryServiceClient;
            _weatherServiceClient = weatherServiceClient;
        }

        public async Task AddCity(City city)
        {
            await _cityRepository.Add(city);
            _cityRepository.Save();
        }

        public async Task DeleteCity(int id)
        {
           await  _cityRepository.Delete(id);
            _cityRepository.Save();
        }

        public async Task<List<CityResponse>> GetCityByName(string name)
        {
            var cityResponse = new List<CityResponse>();
            var cities = await _cityRepository.GetCityByName(name);
            foreach (var city in cities)
            {
                var cityResponseObject = PopulateNewCityResponseObject(city);
                WeatherResponse weatherResponse = await PopulateWeatherInfo(name, cityResponseObject);
                if (weatherResponse.Sys != null)
                {
                    await PopulateCountryInfo(cityResponseObject, weatherResponse);
                }
                cityResponse.Add(cityResponseObject);
            }
            return cityResponse;

        }

 
        public async Task UpdateCity(int id,City city)
        {
            var citi=await _cityRepository.Get(id);
            if (citi != null)
            {
                citi.Rating = city.Rating;
                citi.EstablishedDate = city.EstablishedDate;
                citi.Population = city.Population;
                 _cityRepository.Update(citi);
                _cityRepository.Save();
            }


        }
        #region Helper Methods
        private static CityResponse PopulateNewCityResponseObject(City city)
        {
            var cityResponseObject = new CityResponse
            {
                Id = city.Id,
                Name = city.Name,
                State = city.State,
                Rating = city.Rating,
                EstablishedDate = city.EstablishedDate,
                Population = city.Population
            };
            return cityResponseObject;
        }
        private async Task<WeatherResponse> PopulateWeatherInfo(string name, CityResponse cityResponseObject)
        {
            var weatherResponse = await _weatherServiceClient.GetWeatherByCityName(name);
            if (weatherResponse != null)
            {
                cityResponseObject.Weather = weatherResponse.Weather[0].Description;
            }

            return weatherResponse;
        }
        private async Task PopulateCountryInfo(CityResponse cityResponseObject, WeatherResponse weatherResponse)
        {
            var countryResponse = await _countryServiceClient.GetCountriesByCode(weatherResponse.Sys.Country);
            if (countryResponse != null)
            {
                cityResponseObject.CountryCode2Digit = countryResponse.Alpha2Code;
                cityResponseObject.CountryCode3Digit = countryResponse.Alpha3Code;
                cityResponseObject.CurrencyCode = countryResponse.Currencies[0].Code;
            }
        }
        #endregion
    }
}
