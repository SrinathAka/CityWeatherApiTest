﻿using Deloitte.Test.Core.Interfaces;
using Deloitte.Test.Core.Responses;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace Deloitte.Test.Services
{
    public class CountryServiceClient : ICountryServiceClient
    {
        private HttpClient _client;
        private IConfiguration _configuration;
        public CountryServiceClient(IConfiguration configuration, HttpClient client)
        {
            _configuration = configuration;
            _client = client;
        }
        public async Task<CountryResponse> GetCountriesByCode(string countryCode)
        {
            var baseurl = _configuration.GetSection("CountriesURL").Value;
            var requestUri = baseurl + "alpha/" + countryCode;
            var requestMessage = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri(requestUri)
            };
            var response = await _client.SendAsync(requestMessage);
            var responseContent = await response.Content.ReadAsStringAsync();
            if (response.IsSuccessStatusCode)
            {
                return JsonConvert.DeserializeObject<CountryResponse>(responseContent);
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                //No country Found 
                return null;
            }
            else
            {
                throw new HttpRequestException("Request to country service failed", new Exception(responseContent));
            }
        }
    }
}
