﻿using Deloitte.Test.Core.Interfaces;
using Deloitte.Test.Core.Responses;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace Deloitte.Test.Services
{
    public class WeatherServiceClient : IWeatherServiceClient
    {
        private HttpClient _client;
        private IConfiguration _configuration;
        public WeatherServiceClient(IConfiguration configuration, HttpClient client)
        {
            _configuration = configuration;
            _client = client;
        }

        public async Task<WeatherResponse> GetWeatherByCityName(string name)
        {
            var baseurl = _configuration.GetSection("WeatherURL").Value;
            var requestUri = baseurl + "?q=" + name+"&appid="+ _configuration.GetSection("WeatherAppKey").Value;
            var requestMessage = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri(requestUri)
            };
            var response = await _client.SendAsync(requestMessage);
            var responseContent = await response.Content.ReadAsStringAsync();
            if (response.IsSuccessStatusCode)
            {
                return JsonConvert.DeserializeObject<WeatherResponse>(responseContent);
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                //No city Found 
                return null;
            }
            else
            {
                throw new HttpRequestException("Request to weather service failed", new Exception(responseContent));
            }
        }
    }
}
