﻿using Deloitte.Test.Core.Responses;
using System.Threading.Tasks;

namespace Deloitte.Test.Core.Interfaces
{
    public interface IWeatherServiceClient
    {
        Task<WeatherResponse> GetWeatherByCityName(string name);
    }
}
