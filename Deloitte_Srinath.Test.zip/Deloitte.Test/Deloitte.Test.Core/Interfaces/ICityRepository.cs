﻿using Deloitte.Test.Core.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Deloitte.Test.Core.Interfaces
{
    public interface ICityRepository : IGenericRepository<City>
    {
        Task<List<City>> GetCityByName(string name);
    }
   
}
