﻿namespace Deloitte.Test.Core.Interfaces
{
    public interface IUnitOfWork
    {
        T Get<T>() where T : class;
        void Commit();
        void Clear();
        void Save();
    }
}
