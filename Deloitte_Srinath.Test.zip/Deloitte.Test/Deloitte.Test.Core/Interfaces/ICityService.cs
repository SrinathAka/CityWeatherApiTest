﻿using Deloitte.Test.Core.Models;
using Deloitte.Test.Core.Responses;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Deloitte.Test.Core.Interfaces
{
    public interface ICityService
    {
        Task AddCity(City city);
        Task UpdateCity(int id, City city);
        Task DeleteCity(int id);
        Task<List<CityResponse>> GetCityByName(string name);
    }
}
