﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Deloitte.Test.Core.Interfaces
{
    public interface IGenericRepository<TEntity> where TEntity : class
    {
        IEnumerable<TEntity> GetAll();
        Task<TEntity> Get(int id);
        Task<TEntity> Add(TEntity entity);
        void Update(TEntity entity);
        Task Delete(int id);
        void Save();
    }
}
