﻿using System;

namespace Deloitte.Test.Core.Responses
{
    public class CityResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string State { get; set; }
        public int Rating { get; set; }
        public DateTime EstablishedDate { get; set; }
        public string Population { get; set; }
        public string CountryCode2Digit { get; set; }
        public string CountryCode3Digit { get; set; }
        public string CurrencyCode { get; set; }
        public string Weather { get; set; }
    }
}
