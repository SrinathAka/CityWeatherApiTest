﻿using System.Collections.Generic;

namespace Deloitte.Test.Core.Responses
{
    public class CountryResponse
    {
        public string Alpha2Code { get; set; }
        public string Alpha3Code { get; set; }
        public List<Currency> Currencies { get; set; }
    }

    public class Currency
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public string Symbol { get; set; }
    }
}
