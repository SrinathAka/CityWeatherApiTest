﻿using System.Collections.Generic;

namespace Deloitte.Test.Core.Responses
{
    public class WeatherResponse
    {
        public List<Weather> Weather { get; set; }
        public WeatherSystem Sys { get; set; }
    }

    public class WeatherSystem
    {
        public string Country { get; set; }
    }

    public class Weather
    {
        public int Id { get; set; }
        public string Main { get; set; }
        public string Description { get; set; }
    }
}
