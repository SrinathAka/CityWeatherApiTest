﻿using Deloitte.Test.Core.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;

namespace Deloitte.Test.Core.Models
{
    public class UnitOfWork : IUnitOfWork
    {
        private DbContext _context;
        public UnitOfWork(DbContext context)
        {
            _context = context;
        }

        public void Clear()
        {
            _context = null;
        }

        public void Commit()
        {
            _context.SaveChangesAsync();
        }

        public T Get<T>() where T : class
        {
            return _context as T;
        }

        public void Save()
        {
            throw new NotImplementedException();
        }
    }
}
