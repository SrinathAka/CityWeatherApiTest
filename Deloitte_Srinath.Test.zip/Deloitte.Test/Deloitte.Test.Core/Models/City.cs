﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Deloitte.Test.Core.Models
{
    [Table("Cities")]
    public class City
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string State { get; set; }
        public int Rating { get; set; }
        public DateTime EstablishedDate { get; set; }
        public string Population { get; set; }
    }
}
